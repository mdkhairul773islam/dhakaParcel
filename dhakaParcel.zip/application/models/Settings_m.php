<?php

class Settings_m extends Lab_Model {
    /*protected $_table_name = 'users';
            
    function __construct() {
        parent::__construct();
    }
    
    public function check_existance($table, $where) {
        return $this->existance($table, $where);
    }
    
    public function update_profile($info, $where) {
        return $this->save($info, $where);
    }*/


}

