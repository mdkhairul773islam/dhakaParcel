<?php require_once('Frontend/HomeController.php');
class Home extends HomeController {
    function __construct() {
        parent::__construct();
    }
}
