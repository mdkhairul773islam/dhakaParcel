<div class="container-fluid">
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-heading panal-header">
                <div class="panal-header-title pull-left">
                    <h1>View Branch User</h1>
                </div>
            </div>
            <div class="panel-body">
                <table class="table table-bordered">
                    <tbody>
                        <tr>
                            <td colspan="2" class="text-center">
                                <img src="#" class="img-fluid img-thumbnail" style="height: 100px" alt="branch User">
                            </td>
                        </tr>

                        <tr>
                            <th>Status</th>
                            <td>
                                <span class="bg-success">Active</span>
                            </td>
                        </tr>
                        <tr>
                            <th width="30%">Name</th>
                            <td width="70%">
                                Md shaokat hossain
                            </td>
                        </tr>
                        <tr>
                            <th>Branch</th>
                            <td>
                                Main Branch
                            </td>
                        </tr>
                        <tr>
                            <th>Full Address</th>
                            <td>
                                68/F, Level-1-2,Green Road,
                            </td>
                        </tr>
                        <tr>
                            <th>District</th>
                            <td>
                                District Name
                            </td>
                        </tr>
                        <tr>
                            <th>Thana/Upazila</th>
                            <td>
                                Dhanmondi
                            </td>
                        </tr>
                        <tr>
                            <th>Area</th>
                            <td>
                                Jigatala TSO
                            </td>
                        </tr>
                        <tr>
                            <th>Contact Number</th>
                            <td>
                                01834163689
                            </td>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <td>
                                dhaka@branch.com
                            </td>
                        </tr>
                        <tr>
                            <th>Password</th>
                            <td>
                                12345
                            </td>
                        </tr>

                    </tbody>
                </table>
            </div>
            <div class="panel-footer">&nbsp;</div>
        </div>
    </div>
</div>