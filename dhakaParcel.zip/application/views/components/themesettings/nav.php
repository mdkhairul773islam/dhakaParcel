<div class="container-fluid none" <?php echo $subMenu; ?> style="margin-bottom: 10px;">
    <div class="row">
	    <a href="<?php echo site_url("themesettings/settings"); ?>" class="btn btn-default" id="img_and_text">Images & Text</a>
		<a href="<?php echo site_url("themesettings/settings/address_and_contact"); ?>" class="btn btn-default" id="address_and_contact">Address & Contact</a>
		<a href="<?php echo site_url("themesettings/settings/social_media"); ?>" class="btn btn-default" id="social_media">Social Media</a>
    </div>
</div>