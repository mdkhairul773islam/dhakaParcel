<div class="container-fluid">
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-heading panal-header">
                <div class="panal-header-title pull-left">
                    <h1>View Service Area</h1>
                </div>
            </div>
            <div class="panel-body">
                <table class="table table-sm">
                    <tbody>
                        <tr>
                            <th style="width: 30%;">Status</th>
                            <td style="width: 70%;">
                                <span class="badge bg-secondary">Active</span>
                            </td>
                        </tr>
                        <tr>
                            <th>Name</th>
                            <td>Main Branch</td>
                        </tr>
                        <tr>
                            <th>COD %</th>
                            <td>32%</td>
                        </tr>
                        <tr>
                            <th>Default Charge</th>
                            <td>50</td>
                        </tr>
                        <tr>
                            <th>Weight Type</th>
                            <td>KG</td>
                        </tr>
                        <tr>
                            <th>Details</th>
                            <td>Dhanmondi Test Habijabi</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="panel-footer">&nbsp;</div>
        </div>
    </div>
</div>