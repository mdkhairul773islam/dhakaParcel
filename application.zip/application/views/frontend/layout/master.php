<!doctype html>
<html lang="en">
    <?php 
	    load('frontend.partials.header');
	    load($page);
	    load('frontend.partials.footer');
    ?>
</html>
