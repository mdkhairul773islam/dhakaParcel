<!-- include css -->
<link rel="stylesheet" href="<?=site_url('public/style/credential.css')?>">

<!-- credential section start -->
<section class="credential_section">
    <div class="container">
        <div class="col-lg-10 offset-lg-1">
            <div class="row">
                <div class="col-md-5 pr-0">
                    <div class="welcome_div"></div>
                </div>
                <div class="col-md-7 pl-0">
                    <forgot-password></forgot-password>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- credential section end -->
